# Chess AI Platform

Fullstack project with AI and multiplayer support.